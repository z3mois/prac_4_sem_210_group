#include<iostream>
using namespace std;
class score{
    public:
    score(){}
    score(int n = 1111, const char* nam = " ", const char* time = " ", int money = 0){
        card_number = n;
        name = new char[20];
        time_create = new char[20];
        balance = money;
        int i = 0;
        for (i = 0; i < 20; i++){
            if (nam[i] != '\0')
                name[i] = nam[i];
            else   
                break;
        }
        for (i; i< 20; i++){
            name[i] = ' ';
        }
        i = 0;
        for (i = 0; i < 20; i++){
            if (time[i] != '\0')
                time_create[i] = time[i];
            else 
                break;
        }
        for (i; i< 20; i++){
            time_create[i] = ' ';
        }
        cout<<"create" << '\n';
    }
    score(const score& sc):card_number(sc.card_number), name(sc.name),
    time_create(sc.time_create), balance(sc.balance){
        cout << "copy" << '\n';
    }
    ~score(){
        delete [] name;
        delete [] time_create;
        cout << "~score" << '\n';
    }
    friend ostream& operator << (ostream& out, const score & sc);/// функция-член
    score& operator = (const score & sc){
        card_number = sc.card_number;
        balance = sc.balance;
        int i = 0;
        for (i = 0; i < 20; i++){
            if (sc.name[i] != '\0')
                name[i] = sc.name[i];
            else   
                break;
        }
        for (i; i< 20; i++){
            name[i] = ' ';
        }
        i = 0;
        for (i = 0; i < 20; i++){
            if (sc.time_create[i] != '\0')
                time_create[i] = sc.time_create[i];
            else 
                break;
        }
        for (i; i< 20; i++){
            time_create[i] = ' ';
        }
        cout << "Equal" << '\n';
        return *this;
    };
    private:
        int card_number;
        char* name;
        char* time_create;
        int balance;    
};
    ostream& operator << (ostream& out, const score & sc){
        out << sc.card_number << ' ' << sc.name << ' ' << sc.time_create << ' '<< sc.balance;
        return out;
    }
int main(){
    score A(9275124, "Vasya Volkov\0", "23:12 04.12.2020\0", 10000);
    score B = score(9275124, "Vasya Kozhanov\0", "21:12 03.10.2021\0", 11111);
    cout << A << '\n' << B << '\n';
    A = B;
    cout <<  A << endl;
    return 0;
}